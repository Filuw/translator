﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YandexLinguistics.NET;

namespace Translator
{
    internal class BTranslator
    {
        YandexLinguistics.NET.Translator tr;

        const string translatorKey = "trnsl.1.1.20160627T132638Z.501709d40bb615da.4c7c6ae2bfe3be65efc122c18f876758f34d6a4d";

        public BTranslator()
        {
            tr = new YandexLinguistics.NET.Translator(translatorKey);
        }

        public LanguagePair GetLanguagePair(string inputLang, string outputLang)
        {
            LanguagePair lp = new LanguagePair();
        }
    }
}
