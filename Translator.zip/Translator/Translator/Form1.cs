﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Translator
{
    public partial class Form1 : Form
    {
        ComboBox cd;
        public Form1()
        {
            InitializeComponent();

            comboBox1.SelectedItem = "Русский";

            comboBox2.SelectedItem = "Английский";

            cd = new ComboBox();

            cd.Items.AddRange(new object[] {
            "Азербайджанский",
            "Албанский",
            "Амхарский",
            "Английский",
            "Арабский",
            "Армянский",
            "Африкаанс",
            "Баскский",
            "Башкирский",
            "Белорусский",
            "Бенгальский",
            "Бирманский",
            "Болгарский",
            "Боснийский",
            "Валлийский",
            "Венгерский",
            "Вьетнамский",
            "Гаитянский",
            "Галисийский",
            "Голландский",
            "Горномарийский",
            "Греческий",
            "Грузинский",
            "Гуджарати",
            "Датский",
            "Иврит",
            "Идиш",
            "Индонезийский",
            "Ирландский",
            "Испанский",
            "Итальянский",
            "Исландский",
            "Казахский",
            "Каннада",
            "Каталанский",
            "Киргизский",
            "Китайский",
            "Корейский",
            "Коса",
            "Кхмерский",
            "Лаосский",
            "Латынь",
            "Латышский",
            "Литовский",
            "Люксембургский",
            "Македонский",
            "Малагасийский",
            "Малайский",
            "Малаялам",
            "Мальтийский",
            "Маори",
            "Маратхи",
            "Марийский",
            "Монгольский",
            "Немецкий",
            "Непальский",
            "Нидерландский",
            "Норвежский",
            "Панджаби",
            "Папьяменто",
            "Персидский",
            "Польский",
            "Португальский",
            "Румынский",
            "Русский",
            "Себуанский",
            "Сербский",
            "Сингальский",
            "Словацкий",
            "Словенский",
            "Суахили",
            "Сунданский",
            "Тагальский",
            "Таджикский",
            "Тайский",
            "Тамильский",
            "Татарский",
            "Телугу",
            "Турецкий",
            "Удмуртский",
            "Узбекский",
            "Украинский",
            "Урду",
            "Финский",
            "Французский",
            "Хинди",
            "Хорватский",
            "Чешский",
            "Чувашский",
            "Шведский",
            "Шотландский (Гэльский)",
            "Эльфийский (Синдарин)",
            "Эмодзи",
            "Эсперанто",
            "Эстонский",
            "Яванский",
            "Якутский",
            "Японский"});
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            cd.SelectedItem = comboBox2.SelectedItem;

            comboBox2.SelectedItem = comboBox1.SelectedItem;

            comboBox1.SelectedItem = cd.SelectedItem;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            comboBox1.SelectedItem = "Русский";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            comboBox1.SelectedItem = "Английский";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            comboBox2.SelectedItem = "Немецкий";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            comboBox2.SelectedItem = "Французкий";
        }
    }
}